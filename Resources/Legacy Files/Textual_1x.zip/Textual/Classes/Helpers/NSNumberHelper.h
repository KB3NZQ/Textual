#import <Cocoa/Cocoa.h>

@interface NSNumber (NSNumberHelper)

+ (BOOL)compareIRCColor:(UniChar)c against:(NSInteger)firstNumber;

@end